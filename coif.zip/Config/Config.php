<?php 
	return array(

		"db_user" => "id6985400_bpd237",
		"db_pass" => "Try_Again!0_Coif",
		"db_host" => "localhost",
		"db_name" => "id6985400_gestionexphair"

	);
?>