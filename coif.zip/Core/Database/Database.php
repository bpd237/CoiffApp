<?php

	namespace Core\Database; // Un peu comme le repertoire du fichier actuel

	use \PDO; // On importe PDO

	/**
	 * Class Database
	 * @package Core\Database
	 */
	class Database{
		
	}

?>