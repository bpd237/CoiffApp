<?php

	namespace ExpHairActivityManager\Table;
	use \Core\Table\Table;

	class RestaurationTable extends Table{

	}
?>