<?php

	namespace ExpHairActivityManager\Table;
	use \Core\Table\Table;

	class ProduitTable extends Table{

	}
?>