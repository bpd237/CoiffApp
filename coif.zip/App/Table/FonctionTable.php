<?php

	namespace ExpHairActivityManager\Table;
	use \Core\Table\Table;

	class FonctionTable extends Table{

	}
?>