<?php

	namespace ExpHairActivityManager\Controller\Page;

	class HomeController extends \ExpHairActivityManager\Controller\AppController{

		public function index() {

			$this->render($_SESSION['exphairJKIlHG86djaAef'].'.home.index');
		}
	}
 ?>