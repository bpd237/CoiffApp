<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class FonctionEntity extends Entity{

    }
?>