<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class ClientEntity extends Entity{

    }
?>