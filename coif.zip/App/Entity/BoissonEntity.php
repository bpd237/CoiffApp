<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class BoissonEntity extends Entity{

    }
?>