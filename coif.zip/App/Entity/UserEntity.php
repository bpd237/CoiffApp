<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class UserEntity extends Entity{

    }
?>