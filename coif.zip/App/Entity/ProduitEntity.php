<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class ProduitEntity extends Entity{

    }
?>