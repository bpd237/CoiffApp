<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class PersonnelEntity extends Entity{

    }
?>