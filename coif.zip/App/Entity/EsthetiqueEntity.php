<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class EsthetiqueEntity extends Entity{

    }
?>