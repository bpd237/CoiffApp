<?php

    namespace ExpHairActivityManager\Entity;
    use \Core\Entity\Entity;

    class DetteEntity extends Entity{

    }
?>